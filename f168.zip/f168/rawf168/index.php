<?php
declare(strict_types=1);

/*
  index.php - UI + save endpoint + cleanup (CLI)
  - Web (GET) : tampilkan UI
  - Web (POST): simpan paste, kembalikan JSON { url: ... }
  - CLI (php index.php --cleanup) : jalankan cleanup expired files (unlink)
*/

/* ====== CONFIG ====== */
$BASE_DIR = __DIR__ . '/..';              
$UP_DIR   = $BASE_DIR . '/up';            
$META_DIR = $UP_DIR . '/.meta';           
$MAX_BYTES = 200_000;                     
$ALLOWED_LIFETIME = [60, 1800, 259200];   
$FILENAME_PREFIX = 'raw_';                
$LOCKFILE = sys_get_temp_dir() . '/rawf168_cleanup.lock';
/* ===================== */

/* Ensure directories exist */
if (!is_dir($UP_DIR)) @mkdir($UP_DIR, 0755, true);
if (!is_dir($META_DIR)) @mkdir($META_DIR, 0755, true);

/* ---------- CLI: cleanup mode ---------- */
if (php_sapi_name() === 'cli') {
    $argv = $_SERVER['argv'] ?? [];
    if (in_array('--cleanup', $argv, true) || in_array('-c', $argv, true)) {
        $lock = @fopen($LOCKFILE, 'c');
        if ($lock === false) exit(1);
        if (!flock($lock, LOCK_EX | LOCK_NB)) { fclose($lock); exit(0); }

        $now = time();
        $removed = 0;
        $files = glob($META_DIR . '/' . $FILENAME_PREFIX . '*.txt.json') ?: [];
        foreach ($files as $mfile) {
            $data = @json_decode(@file_get_contents($mfile), true);
            if (!$data || empty($data['file']) || empty($data['expiry'])) { @unlink($mfile); continue; }
            if ((int)$data['expiry'] <= $now) {
                @unlink($UP_DIR . '/' . basename($data['file']));
                @unlink($mfile);
                $removed++;
            }
        }
        flock($lock, LOCK_UN);
        fclose($lock);
        echo "Cleanup done. Removed: $removed\n";
        exit(0);
    }
    echo "Usage: php index.php --cleanup\n";
    exit(0);
}

/* ---------- Web: POST handler ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $title = $_POST['title'] ?? '';
    $lifetime = (int)($_POST['lifetime'] ?? 0);
    $content = $_POST['content'] ?? '';

    if (trim($content) === '') { http_response_code(400); echo json_encode(['error'=>'Content empty']); exit; }
    if (strlen($content) > $MAX_BYTES) { http_response_code(413); echo json_encode(['error'=>'Content too large']); exit; }
    if (!in_array($lifetime, $ALLOWED_LIFETIME, true)) $lifetime = 1800;

    $safeTitle = '';
    if (function_exists('mb_substr')) {
        $safeTitle = preg_replace('/[^\p{L}\p{N}\s_\-\.]/u', '_', mb_substr($title, 0, 120));
    } else {
        $safeTitle = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', substr($title, 0, 120));
    }

    $filename = $FILENAME_PREFIX . bin2hex(random_bytes(16)) . '.txt';
    $filepath = $UP_DIR . '/' . $filename;

    // Simpan HANYA konten
    if (@file_put_contents($filepath, $content, LOCK_EX) === false) {
        http_response_code(500); echo json_encode(['error'=>'Failed to save file']); exit;
    }
    @chmod($filepath, 0644);

    // simpan metadata
    $expiry = time() + $lifetime;
    $meta = ['file'=>$filename, 'expiry'=>$expiry, 'created'=>time(), 'title'=>$safeTitle];
    $metaFile = $META_DIR . '/' . $filename . '.json';
    if (@file_put_contents($metaFile, json_encode($meta), LOCK_EX) === false) {
        @unlink($filepath);
        http_response_code(500); echo json_encode(['error'=>'Failed to save metadata']); exit;
    }
    @chmod($metaFile, 0644);

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'f168.h4ck.me';
    $url = $scheme . '://' . $host . '/up/' . rawurlencode($filename);

    http_response_code(201);
    echo json_encode(['url'=>$url]);
    exit;
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>rawf168 — paste</title>
<style>
  :root{--bg:#0b0c0f;--panel:#0f1114;--text:#8cff7a;--muted:#6b7a7a;}
  html,body{height:100%;margin:0;background:linear-gradient(180deg,#020204 0,#0b0c0f 100%);font-family:ui-monospace,monospace;color:var(--text);}
  .wrap{max-width:980px;margin:24px auto;padding:18px;}
  .card{background:var(--panel);border-radius:8px;padding:18px;box-shadow:0 6px 18px rgba(0,0,0,.6);}
  h1{margin:0 0 12px;font-weight:600;letter-spacing:1px}
  label{display:block;color:var(--muted);font-size:13px;margin-top:12px}
  input,select,textarea{width:100%;background:#070709;border:1px solid #17201a;color:var(--text);padding:12px;border-radius:6px;font-family:inherit;font-size:14px;box-sizing:border-box}
  textarea{min-height:260px;resize:vertical;white-space:pre-wrap;overflow-wrap:break-word}
  .row{display:flex;gap:12px;align-items:center}
  .btn{margin-top:12px;padding:10px 18px;background:#00ff8a;color:#001;border:0;border-radius:6px;cursor:pointer;font-weight:700}
  .note{font-size:13px;color:var(--muted);margin-top:8px}
  .linkbox{margin-top:14px;padding:12px;background:#020202;border:1px solid #0e3e1f;border-radius:6px}
  .error{color:#ff7a7a}
  a.rawlink{color:#8cff7a;word-break:break-all}
  @media(max-width:600px){.row{flex-direction:column}}
</style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>rawf168 — paste</h1>
      <p class="note">Paste teks mentah. Pilih durasi. File tersimpan sebagai <code>.txt</code> di <code>/up/</code>.</p>

      <form id="pasteForm" onsubmit="return submitForm(event)">
        <label for="title">Title (opsional)</label>
        <input id="title" name="title" type="text" maxlength="120">

        <label for="lifetime">Lifetime</label>
        <select id="lifetime" name="lifetime">
          <option value="60">1 menit</option>
          <option value="1800" selected>30 menit</option>
          <option value="259200">3 hari</option>
        </select>

        <label for="content">Paste</label>
        <textarea id="content" name="content" required maxlength="200000"></textarea>

        <div class="row">
          <button class="btn" type="submit">Save</button>
          <div id="status" class="note"></div>
        </div>
      </form>

      <div id="result" style="display:none" class="linkbox">
        <div>Link RAW:</div>
        <a id="rawLink" class="rawlink" href="#" target="_blank"></a>
      </div>
    </div>
  </div>

<script>
async function submitForm(e){
  e.preventDefault();
  const status=document.getElementById('status');
  status.textContent='Menyimpan...';status.className='note';
  document.getElementById('result').style.display='none';

  const form=new FormData(document.getElementById('pasteForm'));
  try{
    const resp=await fetch('index.php',{method:'POST',body:form});
    const data=await resp.json();
    if(!resp.ok){status.textContent=data?.error||'Server error';status.className='error';return;}
    const rawLink=document.getElementById('rawLink');
    rawLink.href=data.url;rawLink.textContent=data.url;
    document.getElementById('result').style.display='block';
    status.textContent='Selesai ✔';
  }catch(err){status.textContent='Gagal terhubung ke server';status.className='error';}
}
</script>
</body>
</html>
