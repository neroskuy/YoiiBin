<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="uikit.css">
    <link rel="stylesheet" href="styles.css">
    <script src="uikit.js"></script>
    <script src="uikit-icons.js"></script>
    <title>YOIBIN</title>
</head>

<body>
    <hr class="uk-margin-xlarge-top uk-margin-xlarge-left uk-margin-xlarge-right">

    <!-- About Section -->
    <section id="about" class="uk-margin-small-left uk-margin-small-right uk-margin-xlarge-top uk-margin-xlarge-bottom">
        <h3 class="uk-margin-xlarge-left uk-light">About Yoibin</h3>
        <p class="uk-margin-xlarge-left uk-margin-xlarge-right">
            Yoibin dirancang untuk memberikan kemudahan dalam berbagi informasi. <br>Dengan antarmuka yang sederhana dan cepat, Yoibin memungkinkan siapa pun, <br>dari pemula hingga profesional, untuk membagikan kode atau teks dalam hitungan detik. <br>Layanan ini tidak memerlukan registrasi, sehingga sangat praktis dan efisien.
        </p>
               <a href="/rawf168/" class="uk-margin-xlarge-left uk-text-capitalize uk-button uk-button-secondary">
  Pake Yoibin
</a>
<br><br>
        <!-- Social Media Links -->
        <div class="uk-margin-xlarge-left">
            <a href="" class="uk-light uk-button-text" uk-icon="instagram"></a>
            <a href="https://github.com/neroskuy" class="uk-light uk-button-text" uk-icon="github"></a>
        </div>
    </section>
</body>

</html>
